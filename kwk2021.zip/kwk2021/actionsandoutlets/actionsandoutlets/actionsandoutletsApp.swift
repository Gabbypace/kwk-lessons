//
//  actionsandoutletsApp.swift
//  actionsandoutlets
//
//  Created by Scholar on 7/28/21.
//

import SwiftUI

@main
struct actionsandoutletsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
