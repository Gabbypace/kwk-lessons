//
//  storyboardintoApp.swift
//  storyboardinto
//
//  Created by Scholar on 7/28/21.
//

import SwiftUI

@main
struct storyboardintoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
