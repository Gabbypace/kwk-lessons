//
//  ViewController.swift
//  miniproject2
//
//  Created by Scholar on 7/29/21.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var question1: UILabel!
    @IBOutlet weak var textfeild1: UITextfeild!
    @IBOutlet weak var answerresponse1: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

   

    @IBAction func submitbutton1(_ sender: Any) {
        if let response = textfeild1.text {
           if response.lowercased() == "raleigh"{
               answerresponse1.text = "That is correct"
            }
          else {
               answerresponse1.text = "I hope you didn't guess Charlotte"
            }
        }
   }
}

