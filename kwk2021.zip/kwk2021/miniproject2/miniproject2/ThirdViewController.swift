//
//  ThirdViewController.swift
//  miniproject2
//
//  Created by Scholar on 7/29/21.
//

import UIKit

class ThirdViewController: UIViewController {

    @IBOutlet weak var question3: UILabel!
    @IBOutlet weak var textfeild3: UITextField!
    @IBOutlet weak var answerrespons3: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func submitbutton3(_ sender: Any) {
        if let response = textfeild3.text{
            if response.lowercased() == "obx"{
                answerrespons3.text = "That is correct"
            }
            else {
                answerrespons3.text = "You don't know your NC beaches"
            }
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
