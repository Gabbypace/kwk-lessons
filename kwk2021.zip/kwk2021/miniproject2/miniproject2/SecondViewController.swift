//
//  SecondViewController.swift
//  miniproject2
//
//  Created by Scholar on 7/29/21.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var question2: UILabel!
    @IBOutlet weak var textfeild2: UITextField!
    @IBOutlet weak var answermessage2: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func submitbutton2(_ sender: Any) {
        if let response = textfeild2.text {
            if response.lowercased() == "Biltmore" {
                answermessage2.text = "That is correct"
            }
            else {
                answermessage2.text = "You haven't seen that amazing commercial for this house then"
            }
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
