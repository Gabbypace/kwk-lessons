//
//  storyboardinto_1App.swift
//  Shared
//
//  Created by Scholar on 7/28/21.
//

import SwiftUI

@main
struct storyboardinto_1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
