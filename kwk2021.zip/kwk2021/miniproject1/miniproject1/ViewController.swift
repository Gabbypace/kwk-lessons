//
//  ViewController.swift
//  miniproject1
//
//  Created by Scholar on 7/28/21.
//

import UIKit

class ViewController: UIViewController {

    var facts = ["These keychains are all places I have been to from Paris to Savannah","I will be majoring in architecture","My favorute food is grilled cheese"]
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var funFactLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func appButton(_ sender: Any) {
        let randomIndex = Int.random(in: 0..<facts.count)
        let randomFact = facts[randomIndex]
        
        funFactLabel.text = randomFact
    }
    
}

