//
//  todo.swift
//  to-do-list-final
//
//  Created by Scholar on 8/2/21.
//

import UIKit
class ToDoClass{
    var description = ""
    var important = false
}
