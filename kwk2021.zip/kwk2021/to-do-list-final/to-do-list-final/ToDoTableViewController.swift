//
//  ToDoTableViewController.swift
//  to-do-list-final
//
//  Created by Scholar on 8/2/21.
//

import UIKit



class ToDoTableViewController: UIViewController {

    func createToDo () -> [ToDoClass] {
        let swiftToDo = ToDoClass()
        swiftToDo.description = "learn swift"
        swiftToDo.important = true
        
        let dogToDo = ToDoClass()
        dogToDo.description = "walk the dog"
        
        return [swiftToDo, dogToDo]
    }
    
    var listOfToDo : [ToDoClass] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
 listOfToDo = createToDo ()
    }
   // override fun tableView(_ tableVeiw: UITableView,
       //                    numberOfRowsInSection section: Int) -> Int {
     //   return 2
    }
   // override fun tableView(_ tableVeiw: UITableView, cellForRowAt
   // indexPath: IndexPath) -> UTITableViewCell {
   // let cell = tableView.dequeuReusablecell(withIdentifier:
  //  "reuseidentifier", for: indexPath)
        
      //  return cell
    
    
        // Do any additional setup after loading the view.
  //  }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */


