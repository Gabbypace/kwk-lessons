//
//  todo.swift
//  to-do-list
//
//  Created by Scholar on 8/2/21.
//

import UIKit

class ToDoClass {
   var description = ""
   var important = false
}
