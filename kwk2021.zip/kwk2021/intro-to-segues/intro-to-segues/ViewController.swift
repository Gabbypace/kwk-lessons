//
//  ViewController.swift
//  intro-to-segues
//
//  Created by Scholar on 7/29/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

